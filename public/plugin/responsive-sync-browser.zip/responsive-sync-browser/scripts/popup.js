document.getElementById("startSync").addEventListener("click", function () {
  // // 백그라운드 스크립트에 새 창을 열고 동기화를 시작하라는 메시지를 보냄
  chrome.runtime.sendMessage({ command: "startSync" });
  window.close(); // Optionally close the popup after action
});

document.getElementById("stopSync").addEventListener("click", function () {
  chrome.runtime.sendMessage({ command: "stopSync" });
  window.close(); // Optionally close the popup after action
});

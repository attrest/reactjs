let sync = false;
let originalTabId = null;
let pairedTabId = null;
let createdWindowId = null; // 연결된 새 창의 ID를 저장하는 변수

// 저장된 상태를 복원
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(["sync", "pairedTabs", "createdWindowId"], function (result) {
    sync = result.sync || false;
    pairedTabs = result.pairedTabs || {};
    createdWindowId = result.createdWindowId || null;
    if (sync && createdWindowId) {
      chrome.windows.get(createdWindowId, { populate: true }, function (window) {
        if (!window) {
          sync = false;
          createdWindowId = null;
          pairedTabId = null;
          chrome.storage.local.set({ sync: false, createdWindowId: null, pairedTabId: null });
        } else {
          pairedTabId = window.tabs[0].id; // Assuming the first tab is the paired tab
        }
      });
    }
  });
});

// 동기화가 활성화된 상태에서 원본 탭의 URL이 변경될 때, 연결된 새 창의 탭도 같은 URL로 업데이트
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (sync && changeInfo.url && tabId === originalTabId) {
    chrome.tabs.update(pairedTabId, { url: changeInfo.url });
  }
});

// 새 창이 닫히면 창 ID와 탭 ID를 리셋하고 동기화를 중지
chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === createdWindowId) {
    createdWindowId = null;
    originalTabId = null;
    pairedTabId = null;
    sync = false;
    chrome.storage.local.set({ sync: false, createdWindowId: null, originalTabId: null, pairedTabId: null });
  }
});

// 팝업에서 동기화 시작 또는 중지 요청을 수신하여 처리
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.command == "startSync") {
    if (createdWindowId === null) {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        originalTabId = tabs[0].id;
        chrome.windows.create({ url: tabs[0].url, type: "normal" }, function (newWindow) {
          if (chrome.runtime.lastError) {
            console.error("Failed to create window: ", chrome.runtime.lastError.message);
            return;
          }
          createdWindowId = newWindow.id;
          pairedTabId = newWindow.tabs[0].id;
          sync = true; // 동기화 상태 활성화
          saveState();
        });
      });
    } else {
      sync = true;
      saveState();
    }
  } else if (request.command == "stopSync") {
    sync = false;
    saveState();
  }
});

// 동기화 상태 저장
function saveState() {
  chrome.storage.local.set({
    sync,
    originalTabId,
    pairedTabId,
    createdWindowId,
  });
}
